insert into employee values(14,'Fancy','F','fancy@gmail.com','10/3/2023');
commit;


