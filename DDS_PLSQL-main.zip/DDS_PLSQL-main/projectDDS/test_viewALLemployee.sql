select * from employee
UNION
select * from employee@site_link;