Delete from EMPLOYEE@site_link where eid=6;

commit;