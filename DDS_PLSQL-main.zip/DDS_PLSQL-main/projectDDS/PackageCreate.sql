create or replace package myPackage as 

	function Generate_Salary(n1 in number)
    return number; 
	
end myPackage;
/