SELECT *
FROM fund1
NATURAL JOIN fund2@site_link;